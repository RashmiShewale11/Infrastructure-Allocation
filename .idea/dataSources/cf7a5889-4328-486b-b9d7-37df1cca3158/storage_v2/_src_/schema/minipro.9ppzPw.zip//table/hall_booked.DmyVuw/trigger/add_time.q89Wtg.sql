create trigger add_time
  after INSERT
  on hall_booked
  for each row
  begin
    declare frm time;
    declare frm1 time;
    declare to1 time;
    declare lab varchar(30);
    declare diff int;
    declare temp int;
    declare dt date;
    set frm=new.from_time;
    set to1=new.to_time;
    set lab=new.hall_no;
    set dt=new.booked_date;

    set diff = hour(subtime(to1,frm));
    set temp = 0;
    while temp < diff do
      set frm1=addtime(frm, '01:00:00');
      insert into hall_timeslot values(lab,dt,frm,frm1);
      set frm=frm1;
      set temp = temp +1 ;
    end while;
  end;

